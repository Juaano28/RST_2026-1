/*
 * main.c
 * Sistema de monitoreo de temperatura con LED RGB y control UART.
 *
 * Hardware:
 *   LED RGB #1 (cátodo común — temperatura):
 *     R → GPIO2    G → GPIO4    B → GPIO5
 *     duty alto = más brillo
 *
 *   LED RGB #2 (ánodo común — botón + potenciómetro):
 *     R → GPIO10   G → GPIO11   B → GPIO15
 *     duty bajo = más brillo (el módulo invierte internamente)
 *
 *   Botón  → GPIO9   (activo en bajo, pull-up interno)
 *
 *   ADC:
 *     NTC (termistor 10kΩ) → GPIO0 (ADC_CHANNEL_0)
 *     Potenciómetro        → GPIO1 (ADC_CHANNEL_1)
 *
 *   Divisor NTC:   3.3V ── 10kΩ ── GPIO0 ── NTC ── GND
 *
 * ── Lógica LED #1 (temperatura) ──────────────────────────────────────
 *   Gradiente de color cada 2 s según temperatura:
 *     < 20°C  → Azul puro
 *     20–35°C → Gradiente azul→verde→rojo
 *     > 35°C  → Rojo puro
 *
 * ── Lógica LED #2 (botón acumulativo) ────────────────────────────────
 *   Estado 0: POT ajusta ROJO  → pulsar guarda rojo
 *   Estado 1: POT ajusta AZUL  → pulsar guarda azul
 *   Estado 2: POT ajusta VERDE → pulsar guarda verde
 *   Estado 3: muestra R+G+B guardados combinados
 *   Siguiente pulso: reset y vuelta al estado 0
 *
 * ── UART (115200 baud) ────────────────────────────────────────────────
 *   Escribe HELP para ver comandos disponibles.
 *   Los ESP_LOGI del loop están desactivados — usan el mismo UART0.
 */

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

#include "library_led_c.h"
#include "adc_module.h"
#include "ntc_module.h"
#include "uart_module.h"
#include "button_led_module.h"

static const char *TAG = "MAIN";

#define TEMP_MIN        20.0f
#define TEMP_MAX        35.0f
#define LOOP_PERIOD_MS  20
#define LED1_UPDATE_MS  2000

void app_main(void)
{
    ESP_LOGI(TAG, "=== Sistema Temperatura RGB iniciando ===");

    /* ── 1. LED RGB #1 (cátodo común, temperatura) ───────────────────── */
    led_rgb_t led_rgb = {
        .led_red   = { .gpio_num = LED_RED_GPIO,   .channel = LEDC_CHANNEL_0,
                       .duty = 0, .duty_min = 0, .duty_max = DUTY_MAX },
        .led_green = { .gpio_num = LED_GREEN_GPIO,  .channel = LEDC_CHANNEL_1,
                       .duty = 0, .duty_min = 0, .duty_max = DUTY_MAX },
        .led_blue  = { .gpio_num = LED_BLUE_GPIO,   .channel = LEDC_CHANNEL_2,
                       .duty = 0, .duty_min = 0, .duty_max = DUTY_MAX },
        .timer           = LEDC_TIMER_0,
        .duty_resolution = LEDC_TIMER_13_BIT,
        .frequency       = 1000,
        .speed_mode      = LEDC_LOW_SPEED_MODE,
    };
    config_led_rgb(&led_rgb);

    /* ── 2. ADC (NTC en CH0, POT en CH1) ────────────────────────────── */
    adc_module_t adc;
    adc_module_init(&adc);

    /* ── 3. UART ─────────────────────────────────────────────────────── */
    uart_module_t uart_mod;
    uart_module_init(&uart_mod, &led_rgb, &adc);

    /* ── 4. LED RGB #2 (ánodo común, botón + POT) ───────────────────── */
    button_led_module_t btn_led;
    button_led_module_init(&btn_led);

    ESP_LOGI(TAG, "Sistema listo — escribe HELP.");
    ESP_LOGI(TAG, "LED#1 catodo comun: R=GPIO%d G=GPIO%d B=GPIO%d",
             (int)LED_RED_GPIO, (int)LED_GREEN_GPIO, (int)LED_BLUE_GPIO);
    ESP_LOGI(TAG, "LED#2 anodo comun:  R=GPIO%d G=GPIO%d B=GPIO%d  BTN=GPIO%d",
             (int)BTN_LED_RED_GPIO, (int)BTN_LED_GREEN_GPIO,
             (int)BTN_LED_BLUE_GPIO, (int)BTN_GPIO);

    /* ── 5. Loop principal ──────────────────────────────────────────── */
    uint32_t ticks = 0;
    const uint32_t led1_ticks = LED1_UPDATE_MS / LOOP_PERIOD_MS;

    while (1) {
        uart_module_process(&uart_mod);
        button_led_module_process(&btn_led, &adc);

        if (++ticks >= led1_ticks) {
            ticks = 0;
            int ntc_raw, ntc_mv;
            adc_module_read_ntc(&adc, &ntc_raw, &ntc_mv);
            float temp = ntc_voltage_to_celsius(ntc_mv);
            set_led_rgb_by_temperature(&led_rgb, temp, TEMP_MIN, TEMP_MAX);
            /*
             * Log desactivado — satura UART0. Usar READ_TEMP por terminal.
             * Para debug puntual descomentar:
             * ESP_LOGI(TAG, "T=%.2fC V=%dmV R=%u G=%u B=%u", temp, ntc_mv,
             *     (unsigned)led_rgb.led_red.duty,
             *     (unsigned)led_rgb.led_green.duty,
             *     (unsigned)led_rgb.led_blue.duty);
             */
        }

        vTaskDelay(pdMS_TO_TICKS(LOOP_PERIOD_MS));
    }
}